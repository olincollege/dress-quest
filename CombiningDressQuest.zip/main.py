import pygame
from fp_game import Game as fp_Game
from fp_view import View as fp_View
from fp_player import Player as fp_Player
from fp_controller import Controller as fp_Controller
from fp_platforms import Platforms as fp_Platforms
from dg_player import Player as dg_Player
from dg_controller import Controller as dg_Controller
from dg_view import View as dg_View
from dg_game import Game as dg_Game

#dress up game classes
dg_game = dg_Game()
dg_player = dg_Player()
dg_controller = dg_Controller(dg_game, dg_player)
dg_view = dg_View(dg_game, dg_player)

#frog platform classes
fp_game = fp_Game()
fp_player = fp_Player(fp_game)
fp_platforms = fp_Platforms(fp_game)
fp_view = fp_View(fp_game, fp_player, fp_platforms)
fp_controller = fp_Controller(fp_game, fp_player)

while dg_game.running:
  #run the dress up game
  while dg_game.dress_up_running:
      for event in pygame.event.get():  
          if pygame.key.get_pressed()[pygame.K_RETURN]:
              dg_game.dress_up_running = False 
                
      dg_game.update()
    
      dg_controller.change_clothes()
      
      dg_view.draw_bg()
      dg_view.draw_instructions()
      dg_view.draw_clothes()
      dg_view.draw_arrows()
    
      dg_view.update()

  #run the platform game
  fp_view.draw_bg()
  fp_view.draw_player()
  fp_view.draw_platforms()

  fp_controller.move_player()
  fp_player.update_pos(fp_platforms.group, fp_game)

  fp_platforms.generate()
  fp_platforms.scroll()

  fp_game.update()
  fp_view.update()
  

pygame.quit()
