from fp_game import Game as fp_Game
from fp_view import View as fp_View
from fp_player import Player as fp_Player
from fp_controller import Controller as fp_Controller
from fp_platforms import Platforms as fp_Platforms

def main():

    fp_game = fp_Game()
    fp_player = fp_Player(game)
    fp_platforms = fp_Platforms(game)
    
    fp_view = fp_View(fp_game, fp_player, fp_platforms)

    fp_controller = fp_Controller(fp_game, fp_player)
    
    while fp_game.running:
        fp_view.draw_bg()
        fp_view.draw_player()
        fp_view.draw_platforms()

        fp_controller.move_player()
        fp_player.update_pos(platforms.group)

        fp_platforms.generate()
        fp_platforms.scroll()

        fp_game.update()
        fp_view.update()



main()