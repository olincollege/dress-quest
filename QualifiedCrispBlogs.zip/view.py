import pygame

class View:
    def __init__(self, game, player):
        self._game = game
        self._player = player

    def draw_bg(self):
      self._game.screen.blit(self._game.bg_img, (0, 0))
      self._game.screen.blit(self._game.fg_img, (0, 0))
  
    def draw_clothes(self):
        for i in range(3):
            self._game.screen.blit(self._player.images[i], \
                self._player.coords[i])
    
    def draw_instructions(self):
        self._game.screen.blit(self._game.bg_img, (0, 0))
        self._game.screen.blit(self._game.fg_img, (0, 0))
        self._game.screen.blit(self._game.instructions_img, (0, 0))
    
    def draw_arrows(self):
        self._game.screen.blit(pygame.image.load(\
            self._game.ARROWS[self.game.item]), (0, 0))

