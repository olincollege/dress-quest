import pygame

class Game:
    SCREEN_WIDTH = 500
    SCREEN_HEIGHT = 668

    ARROWS = [
        'sela_test_images/top_select.png', \
        'sela_test_images/mid_select.png', \
        'sela_test_images/bottom_select.png'
    ]

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((self.SCREEN_WIDTH, \
            self.SCREEN_HEIGHT))

        self.bg_img = pygame.image.load('sela_test_images/back_bg_layer.png')
        self.fg_img = pygame.image.load('sela_test_images/front_bg_layer.png')
        self.instructions_img = pygame.image.load('sela_test_images/instructions.png')

        self.running = True
        
        self.item = 0
    
    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.KEYDOWN:
                self.instructions_img = pygame.image.load('sela_test_images/enter_instruct.png')
