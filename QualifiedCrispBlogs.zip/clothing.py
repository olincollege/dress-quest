bottoms = {
    'sela_test_images/invisible.png': (0, 0),
    'clothes/black_bottom.png': (159, 522),
    'clothes/blue_bottom.png': (142, 524),
    'clothes/creep_bottom.png': (142, 524),
    'clothes/fish_bottom.png': (115, 524),
    'clothes/flannel_bottom.png': (142, 524),
    'clothes/grey_bottom.png': (142, 524),
    'clothes/net_bottom.png': (126, 528),
    'clothes/rainbow_bottom.png': (142, 524),
    'clothes/red_bottom.png': (179, 529),
    'clothes/thigh_bottom copy.png': (109, 526),
    'clothes/yellow_bottom.png': (142, 524)
}

tops = [
    ['sela_test_images/invisible.png', (0,0)],
    ['clothes/blue_top.png', (176,520)],
    ['clothes/flag_top.png', (192,521)],
    ['clothes/flannel_top.png', (170,522)],
    ['clothes/ocean_top.png', (144,523)],
    ['clothes/pearl_top.png', (198,518)],
    ['clothes/rainbow_top.png', (177,522)],
    ['clothes/red_top.png', (199,537)],
    ['clothes/tank_top.png', (190,522)],
    ['clothes/tie_top.png', (240,541)]
]

hats = [
    ['sela_test_images/invisible.png', (0,0)],
    ['clothes/cap_hat.png', (205,435)],
    ['clothes/cat_hat.png', (190,457)],
    ['clothes/cow_hat.png', (160,430)],
    ['clothes/horn_hat.png', (205,432)],
    ['clothes/straw_hat.png', (165,437)],
    ['clothes/sun_hat.png', (199,490)],
    ['clothes/unicorn_hat.png', (236,440)]
]